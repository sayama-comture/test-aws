# 1. プロジェクトディレクトリに移動
cd qdrant-docker

# 2. Dockerイメージをビルド
docker build -t qdrant-custom:latest .

# 3. ビルドしたイメージの確認
docker images | grep qdrant-custom

# 4. ローカルでのテスト実行
docker run -d \
  --name qdrant-test \
  -p 6333:6333 \
  -p 6334:6334 \
  -v qdrant_storage:/qdrant/storage \
  qdrant-custom:latest

# 5. 動作確認
curl http://localhost:6333/health