import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as elbv2 from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import { Construct } from 'constructs';
import { KubectlV32Layer } from '@aws-cdk/lambda-layer-kubectl-v32';
import * as eks from '@aws-cdk/aws-eks-v2-alpha';

export interface QdrantEksStackProps extends cdk.StackProps {

  acmArn: string;
  isPublic: boolean;
  vpcId: string;
  availabilityZones: string[];
  publicSubnetIds: string[];
  privateSubnetIds: string[];
  vpcCidr: string;
  systemName: string;
    
  // リソース名設定
  resourcePrefix: string;
  clusterName?: string;
  nodeGroupName?: string;
  
  // Qdrant設定
  // qdrantVersion?: string;
  // qdrantReplicas?: number;
  // qdrantStorageSize?: string;
  
  // EKS設定
  kubernetesVersion?: eks.KubernetesVersion;
  instanceTypes?: ec2.InstanceType[];
  minSize?: number;
  maxSize?: number;
  desiredSize?: number;
}

export class CdkQdrantStack extends cdk.Stack {
  public readonly cluster: eks.Cluster;
  public readonly vpc: ec2.IVpc;

  constructor(scope: Construct, id: string, props: QdrantEksStackProps) {
    super(scope, id, props);

    // デフォルト値の設定
    const resourcePrefix = props.resourcePrefix;
    const clusterName = props.clusterName || `${resourcePrefix}-qdrant-cluster`;
    const nodeGroupName = props.nodeGroupName || `${resourcePrefix}-qdrant-nodegroup`;
    // const qdrantVersion = props.qdrantVersion || 'v1.7.4';
    // const qdrantReplicas = props.qdrantReplicas || 1;
    // const qdrantStorageSize = props.qdrantStorageSize || '10Gi';

    // VPCの作成または取得
    this.vpc = this.Vpc(props, resourcePrefix);

    const adminSsoRole = iam.Role.fromRoleName(
      this,
      'IicAdminRole',
      'AWSReservedSSO_AdministratorAccess_53ea33b610176220',
    );

    // EKSクラスターの作成
    this.cluster = this.createEksCluster(
      clusterName,
      nodeGroupName,
      resourcePrefix,
      props
    );

    // Qdrantのデプロイ
    // this.deployQdrant(qdrantVersion, qdrantReplicas, qdrantStorageSize, resourcePrefix);

    // Load Balancerの作成
    // this.createLoadBalancer(resourcePrefix);

    // 出力
    // this.createOutputs(clusterName);
  }

  private Vpc(props: QdrantEksStackProps, resourcePrefix: string): ec2.IVpc {
    return ec2.Vpc.fromLookup(this, `${resourcePrefix}-vpc`, {
      vpcId: props.vpcId
    });
  }
  
  private createEksCluster(
    clusterName: string,
    nodeGroupName: string,
    resourcePrefix: string,
    props: QdrantEksStackProps
  ): eks.Cluster {
    
    // クラスターロールの作成
    const clusterRole = new iam.Role(this, `${resourcePrefix}-cluster-role`, {
      roleName: `${resourcePrefix}-eks-cluster-role`,
      assumedBy: new iam.ServicePrincipal('eks.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSClusterPolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSBlockStoragePolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSComputePolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSLoadBalancingPolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSNetworkingPolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AdministratorAccess')
      ],
    });

    // 既存ロールを更新する場合は保険として追記
    clusterRole.assumeRolePolicy!.addStatements(
      new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        principals: [new iam.ServicePrincipal('eks.amazonaws.com')],
        actions: ['sts:AssumeRole'],
      }),
    );

    // ノードグループロールの作成
    const nodeGroupRole = new iam.Role(this, `${resourcePrefix}-nodegroup-role`, {
      roleName: `${resourcePrefix}-eks-nodegroup-role`,
      assumedBy: new iam.ServicePrincipal('ec2.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSWorkerNodePolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKS_CNI_Policy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEC2ContainerRegistryReadOnly'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonSSMManagedInstanceCore'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AdministratorAccess')
      ],
    });

    const kubectl = new KubectlV32Layer(this, `${resourcePrefix}-kubectl-v32`);

   // v2-alphaに変更
    const cluster = new eks.Cluster(this, `${resourcePrefix}-cluster`, {
      clusterName: clusterName,
      version: props.kubernetesVersion || eks.KubernetesVersion.V1_32,
      role: clusterRole,
      vpc: this.vpc,
      vpcSubnets: [
        {
          subnets: props.privateSubnetIds.map((subnetId, index) =>
            ec2.Subnet.fromSubnetAttributes(this, `PrivateSubnet${index}`, {
              subnetId
            }),
          ),
        },
      ],
      endpointAccess: eks.EndpointAccess.PUBLIC_AND_PRIVATE,
      clusterLogging: [
        eks.ClusterLoggingTypes.API,
        eks.ClusterLoggingTypes.AUDIT,
        eks.ClusterLoggingTypes.AUTHENTICATOR,
        eks.ClusterLoggingTypes.CONTROLLER_MANAGER,
        eks.ClusterLoggingTypes.SCHEDULER,
      ],
      tags: {
        System: props.systemName
      },
    });

    // AmazonEKSClusterAdminPolicy with `cluster` scope
    const adminAccessPolicy = eks.AccessPolicy.fromAccessPolicyName('AmazonEKSClusterAdminPolicy', {
      accessScopeType: eks.AccessScopeType.CLUSTER,
    });
    
    // AmazonEKSAdminPolicy with `namespace` scope
    // eks.AccessPolicy.fromAccessPolicyName('AmazonEKSAdminPolicy', {
    //   accessScopeType: eks.AccessScopeType.NAMESPACE,
    //   namespaces: ['foo', 'bar'] } );

    // ノードグループの作成
    // cluster.addNodegroupCapacity(`${resourcePrefix}-nodegroup`, {
    //   nodegroupName: nodeGroupName,
    //   instanceTypes: props.instanceTypes || [new ec2.InstanceType('t3.medium')],
    //   minSize: props.minSize || 1,
    //   maxSize: props.maxSize || 5,
    //   desiredSize: props.desiredSize || 2,
    //   nodeRole: nodeGroupRole,
    //   subnets: {
    //     subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
    //   },
    //   amiType: eks.NodegroupAmiType.AL2023_X86_64_STANDARD,
    //   capacityType: eks.CapacityType.ON_DEMAND,
    //   diskSize: 30,
    //   labels: {
    //     'app': 'qdrant',
    //     'environment': resourcePrefix,
    //   },
    //   taints: [],
    // });
  return cluster;
  }
}