// Infra-Stack インフラ構成（EKS + ALB Controller）
import { Stack, StackProps, Duration, CfnOutput } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as eksv2 from '@aws-cdk/aws-eks-v2-alpha';
import * as iam from 'aws-cdk-lib/aws-iam';
import { KubectlV32Layer } from '@aws-cdk/lambda-layer-kubectl-v32';

export interface InfraStackProps extends StackProps {
  vpcId: string;
  privateSubnetIds: string[];
  publicSubnetIds: string[];
  resourcePrefix: string;
  systemName: string;
  clusterName: string;
}

export class CdkQdrantInfraStack extends Stack {
  public readonly cluster: eksv2.Cluster;
  public readonly albSecurityGroup: ec2.SecurityGroup;

  constructor(scope: Construct, id: string, props: InfraStackProps) {
    super(scope, id, props);

    const vpc = ec2.Vpc.fromLookup(this, 'Vpc', { vpcId: props.vpcId });

    const clusterRole = new iam.Role(this, `${props.resourcePrefix}-eks-cluster-role`, {
      assumedBy: new iam.ServicePrincipal('eks.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSClusterPolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSServicePolicy'),
      ],
    });

    const kubectl = new KubectlV32Layer(this, `${props.resourcePrefix}-kubectl-v32`);

    this.cluster = new eksv2.Cluster(this, `${props.resourcePrefix}-cluster`, {
      clusterName: props.clusterName,
      version: eksv2.KubernetesVersion.V1_32,
      role: clusterRole,
      kubectlProviderOptions: {
        kubectlLayer: kubectl,
      },
      vpc,
      vpcSubnets: [
        { subnets: props.privateSubnetIds.map((id, i) => ec2.Subnet.fromSubnetId(this, `PrivateSubnet${i}`, id)) }
      ],
      defaultCapacityType: eksv2.DefaultCapacityType.AUTOMODE,
    });

    // 管理者ロールARNの定義
    const adminSsoRoleArn = `arn:aws:iam::${cdk.Aws.ACCOUNT_ID}:role/aws-reserved/sso.amazonaws.com/ap-northeast-1/AWSReservedSSO_AdministratorAccess_53ea33b610176220`;

    // アクセスエントリの作成
    const adminAccessEntry = new cdk.aws_eks.CfnAccessEntry(this, 'AdminSsoAccessEntry', {
      clusterName: this.cluster.clusterName,
      principalArn: adminSsoRoleArn,
      type: 'STANDARD',
      accessPolicies: [{
        policyArn: 'arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy',
        accessScope: {
          type: 'cluster',
        },
      }],
    });
    adminAccessEntry.node.addDependency(this.cluster);

    // Kubernetes内でのClusterRoleBindingを追加
    this.cluster.addManifest('SsoAdminClusterRoleBinding', {
      apiVersion: 'rbac.authorization.k8s.io/v1',
      kind: 'ClusterRoleBinding',
      metadata: {
        name: 'sso-admin-cluster-admin'
      },
      roleRef: {
        apiGroup: 'rbac.authorization.k8s.io',
        kind: 'ClusterRole',
        name: 'cluster-admin'
      },
      subjects: [{
        kind: 'User',
        name: adminSsoRoleArn,
        apiGroup: 'rbac.authorization.k8s.io'
      }]
    });

    // ALB Controller Webhook 用 (port 9443)
    this.cluster.clusterSecurityGroup.addIngressRule(
      this.cluster.clusterSecurityGroup,      // Source: Control-plane SG
      ec2.Port.tcp(9443),
      'Allow control-plane to reach ALB controller webhook'
    );

    // セキュリティグループ
    this.albSecurityGroup = new ec2.SecurityGroup(this, 'AlbSG', {
      vpc,
      allowAllOutbound: true,
      description: 'Security group for ALB',
    });

    this.albSecurityGroup.addIngressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(443));

    // ALB Controller
    const sa = this.cluster.addServiceAccount('AWSLoadBalancerController', {
      name: 'aws-load-balancer-controller',
      namespace: 'kube-system'
    });

    sa.addToPrincipalPolicy(new iam.PolicyStatement({
      actions: ['elasticloadbalancing:*', 'ec2:*', 'iam:PassRole'],
      resources: ['*']
    }));

    this.cluster.addHelmChart('ALBControllerChart', {
      chart: 'aws-load-balancer-controller',
      repository: 'https://aws.github.io/eks-charts',
      namespace: 'kube-system',
      wait: true,
      values: {
        clusterName: this.cluster.clusterName,
        region: Stack.of(this).region,
        vpcId: vpc.vpcId,
        serviceAccount: { create: false, name: sa.serviceAccountName },
        image: {
          repository: `602401143452.dkr.ecr.${Stack.of(this).region}.amazonaws.com/amazon/aws-load-balancer-controller`
        }
      }
    });

    new CfnOutput(this, 'ClusterName', {
      value: this.cluster.clusterName
    });
  }
}