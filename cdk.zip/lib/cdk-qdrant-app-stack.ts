import * as cdk from 'aws-cdk-lib';
import { Stack, StackProps, Duration, CfnOutput } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as eks from '@aws-cdk/aws-eks-v2-alpha';
import * as ecr from "aws-cdk-lib/aws-ecr";
import * as ecrdeploy from "cdk-ecr-deployment";

export interface AppStackProps extends StackProps {
  cluster: eks.ICluster;
  publicSubnetIds: string[];
  privateSubnetIds: string[];
  albSecurityGroupId: string;
  resourcePrefix: string;
  systemName: string;
  vpcId: string;
  clusterName: string;
  ecrRepository: ecr.Repository;
  ecrDeployment: ecrdeploy.ECRDeployment;
}

export class CdkQdrantAppStack extends Stack {

  constructor(scope: Construct, id: string, props: AppStackProps) {
    super(scope, id, props);

    const systemName = props.systemName.toLowerCase();
    const namespace = 'qdrant';
    const appName = 'qdrant';

    // ─────────── Kubernetes Manifests ───────────

    const namespaceManifest = props.cluster.addManifest('QdrantNamespace', {
      apiVersion: 'v1',
      kind: 'Namespace',
      metadata: { name: namespace }
    });

    // ─────────── StorageClass (EBS gp3) - 必要？？指定しないとgp2で作成される
    const storageClass = props.cluster.addManifest('QdrantStorageClass', {
      apiVersion: 'storage.k8s.io/v1',
      kind: 'StorageClass',
      metadata: {
        name: `${appName}-storage`,
      },
      provisioner: 'ebs.csi.eks.amazonaws.com',
      volumeBindingMode: 'WaitForFirstConsumer',
      parameters: {
        type: 'gp3',
        iops: '3000',
        throughput: '150',
        encrypted: 'true'
      },
      allowVolumeExpansion: true,
      reclaimPolicy: 'Retain'
    });
    storageClass.node.addDependency(namespaceManifest);

    // // ─────────── PersistentVolumeClaim - 新規追加
    const pvc = props.cluster.addManifest('QdrantPVC', {
      apiVersion: 'v1',
      kind: 'PersistentVolumeClaim',
      metadata: {
        name: `${appName}-storage`,
        namespace
      },
      spec: {
        accessModes: ['ReadWriteOnce'],
        storageClassName: `${appName}-storage`,
        resources: {
          requests: {
            storage: '35Gi'
          }
        }
      }
    });
    pvc.node.addDependency(storageClass);

    // 一時的にServiceAccountを使わずにデフォルトのServiceAccountを使用
    // まずイメージpullの問題を解決してから、ECR認証を追加
    const configMap = props.cluster.addManifest('QdrantConfigMap', {
      apiVersion: 'v1',
      kind: 'ConfigMap',
      metadata: { name: `${appName}-config`, namespace },
      data: {
        'QDRANT__SERVICE__HTTP_PORT': '6333',
        'QDRANT__SERVICE__GRPC_PORT': '6334',
        'QDRANT__STORAGE__STORAGE_PATH': '/qdrant/storage' // ストレージパスを明示的に指定
      }
    });
    configMap.node.addDependency(namespaceManifest);

    // まずは簡単なイメージでテスト - 永続ストレージ対応
    const deployment = props.cluster.addManifest('QdrantDeployment', {
      apiVersion: 'apps/v1',
      kind: 'Deployment',
      metadata: { name: `${appName}-deployment`, namespace },
      spec: {
        replicas: 1, // PersistentVolumeを使用する場合は1レプリカ
        selector: { matchLabels: { app: appName } },
        template: {
          metadata: { labels: { app: appName } },
          spec: {
            containers: [{
              name: appName,
              // 一時的にパブリックイメージを使用してServiceAccountの問題を切り分け
              // image: 'qdrant/qdrant:v1.7.4', // または props.ecrRepository.repositoryUri + ':latest'
              image: props.ecrRepository.repositoryUri + ':latest',
              ports: [
                { containerPort: 6333, name: 'http' },
                { containerPort: 6334, name: 'grpc' }
              ],
              envFrom: [{ configMapRef: { name: `${appName}-config` } }],
              // EBSボリュームをマウント - 新規追加
              volumeMounts: [{
                name: 'qdrant-storage',
                mountPath: '/qdrant/storage'
              }],
              // ヘルスチェックを復活（永続ストレージで安定性向上）
              livenessProbe: {
                httpGet: {
                  path: '/',
                  port: 6333
                },
                initialDelaySeconds: 30,
                periodSeconds: 10
              },
              readinessProbe: {
                httpGet: {
                  path: '/',
                  port: 6333
                },
                initialDelaySeconds: 10,
                periodSeconds: 5
              },
              resources: {
                requests: {
                  memory: '512Mi',
                  cpu: '250m'
                },
                limits: {
                  memory: '1Gi',
                  cpu: '500m'
                }
              }
            }],
            // PersistentVolumeClaimを指定
            volumes: [{
              name: 'qdrant-storage',
              persistentVolumeClaim: {
                claimName: `${appName}-storage`
              }
            }]
          }
        }
      }
    });
    // deployment.node.addDependency(configMap, pvc); // pvcへの依存関係も追加
    deployment.node.addDependency(configMap); // pvcへの依存関係も追加

    const service = props.cluster.addManifest('QdrantService', {
      apiVersion: 'v1',
      kind: 'Service',
      metadata: {
        name: `${appName}-service`,
        namespace,
        labels: { app: appName } // ラベル追加
      },
      spec: {
        selector: { app: appName },
        ports: [
          { port: 6333, targetPort: 6333, name: 'http' },
          { port: 6334, targetPort: 6334, name: 'grpc' }
        ],
        type: 'ClusterIP'
      }
    });
    service.node.addDependency(deployment);


    const ingress = props.cluster.addManifest('QdrantIngress', {
      apiVersion: 'networking.k8s.io/v1',
      kind: 'Ingress',
      metadata: {
        name: `${appName}-ingress`,
        namespace,
        annotations: {
          'kubernetes.io/ingress.class': 'alb',
          'alb.ingress.kubernetes.io/scheme': 'internal',
          'alb.ingress.kubernetes.io/target-type': 'ip',
          'alb.ingress.kubernetes.io/subnets': props.privateSubnetIds.join(','),
          'alb.ingress.kubernetes.io/security-groups': props.albSecurityGroupId,
          'alb.ingress.kubernetes.io/listen-ports': '[{"HTTP":80}]',
          'alb.ingress.kubernetes.io/ssl-redirect': '443',
          'alb.ingress.kubernetes.io/healthcheck-path': '/dashboard',
          'alb.ingress.kubernetes.io/healthcheck-port': '6333',
          'alb.ingress.kubernetes.io/backend-protocol': 'HTTP',
          'alb.ingress.kubernetes.io/load-balancer-attributes': 'idle_timeout.timeout_seconds=60'
        }
      },
      spec: {
        rules: [{
          http: {
            paths: [{
              path: '/',
              pathType: 'Prefix',
              backend: {
                service: {
                  name: `${appName}-service`,
                  port: { number: 6333 }
                }
              }
            }]
          }
        }]
      }
    });
    ingress.node.addDependency(service);

    new CfnOutput(this, 'EcrRepositoryUri', {
      value: props.ecrRepository.repositoryUri,
      description: 'ECR Repository URI'
    });

    new CfnOutput(this, 'QdrantNamespace', {
      value: namespace,
      description: 'Qdrant Kubernetes Namespace'
    });

    // ストレージ情報を追加
    // new CfnOutput(this, 'StorageInfo', {
    //   value: `PVC: ${appName}-storage (20Gi EBS gp3, encrypted)`,
    //   description: 'Persistent Storage Information'
    // });

    new CfnOutput(this, 'DebugCommands', {
      value: [
        'kubectl get pods -n qdrant',
        'kubectl describe pod -n qdrant -l app=qdrant',
        'kubectl get events -n qdrant --sort-by=.metadata.creationTimestamp'
      ].join(' && '),
      description: 'Debug commands'
    });

    // ストレージ確認用コマンドを追加
    new CfnOutput(this, 'StorageCommands', {
      value: [
        'kubectl get pv,pvc -n qdrant',
        'kubectl describe pvc qdrant-storage -n qdrant',
        'kubectl exec -n qdrant deployment/qdrant-deployment -- df -h /qdrant/storage',
        'kubectl exec -n qdrant deployment/qdrant-deployment -- ls -la /qdrant/storage'
      ].join(' && '),
      description: 'Storage verification commands'
    });
  }
}