import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { RemovalPolicy } from "aws-cdk-lib";
import { Stack, StackProps, CfnOutput } from 'aws-cdk-lib';
import { DockerImageAsset, Platform } from "aws-cdk-lib/aws-ecr-assets";
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as path from 'path';
import * as ecr from "aws-cdk-lib/aws-ecr";
import * as ecrdeploy from "cdk-ecr-deployment";
import * as ec2 from 'aws-cdk-lib/aws-ec2';

export interface GitLoaderStackProps extends StackProps {
  resourcePrefix: string;
  qdrantUrl: string;
  vpcId: string;
  privateSubnetIds: string[];
}

export class CdkGitLoaderStack extends Stack {

  public readonly ecrRepository: ecr.Repository;

  constructor(scope: Construct, id: string, props: GitLoaderStackProps) {
    super(scope, id, props);

    const systemName = props.resourcePrefix.toLowerCase();

    /*────────────────── 1. ECR Repository with LifeCycle Rule ──────────────────*/
    this.ecrRepository = new ecr.Repository(this, "gitloader-repo-" + systemName, {
      repositoryName: "gitloader-repository-" + systemName,
      removalPolicy: RemovalPolicy.DESTROY,
      lifecycleRules: [{
        rulePriority: 1,
        description: "Delete untagged images older than 30 days, exclude 'latest'",
        maxImageAge: cdk.Duration.days(30),
        tagStatus: ecr.TagStatus.UNTAGGED
      }, {
        rulePriority: 2,
        description: "Keep only the last 2 images with 'latest' tag",
        maxImageCount: 2,
        tagPrefixList: ['latest']
      }]
    });

    const asset = new DockerImageAsset(this, "gitloader-dockerimageAsset-" + systemName, {
      directory: path.join(__dirname, "..", "lambda"),
      platform: Platform.LINUX_AMD64,
    });

    // ECR イメージの登録
    const ecrDeployment = new ecrdeploy.ECRDeployment(this, "gitloader-imagedeploy-" + systemName, {
      src: new ecrdeploy.DockerImageName(asset.imageUri),
      dest: new ecrdeploy.DockerImageName(`${cdk.Aws.ACCOUNT_ID}.dkr.ecr.${cdk.Aws.REGION}.amazonaws.com/${this.ecrRepository.repositoryName}:latest`),
    });

    /*────────────────── 2-1. VPCとサブネット参照 ──────────────────*/
    // 既存のVPCを参照
    const vpc = ec2.Vpc.fromLookup(this, 'ExistingVpc', {
      vpcId: props.vpcId
    });

    // サブネットを参照
    const subnets = props.privateSubnetIds.map((subnetId: string, index: number) =>
      ec2.Subnet.fromSubnetId(this, `LambdaSubnet${index}`, subnetId)
    );

    /*────────────────── 2-2. セキュリティグループ作成 ──────────────────*/
    const lambdaSecurityGroup = new ec2.SecurityGroup(this, 'GitLoaderLambdaSecurityGroup', {
      vpc: vpc,
      securityGroupName: systemName + '-gitloader-lambda-sg',
      description: 'Security group for GitLoader Lambda function',
      allowAllOutbound: true,
    });

    /*────────────────── 2-3. Lambda GitLoaderFunction Role ──────────────────*/
    const gitLoaderExecutionRole = new iam.Role(this, 'GitLoaderExecutionRole', {
      roleName: systemName + '-gitloader-execution-role',
      assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
      description: 'Execution role for GitLoader Lambda function with PowerUserAccess',
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaVPCAccessExecutionRole'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('PowerUserAccess')
      ],
    });

    /*────────────────── 2-4. Lambda GitLoaderFunction ──────────────────*/
    const GitLoaderFunction = new lambda.DockerImageFunction(this, 'GitLoaderFunction', {
      functionName: systemName + '-gitloader-function',
      architecture: lambda.Architecture.X86_64,
      code: lambda.DockerImageCode.fromEcr(this.ecrRepository, {
        tag: 'latest',
      }),

      memorySize: 1024,
      timeout: cdk.Duration.minutes(15),
      description: 'GitLoader and Indexing Function',
      role: gitLoaderExecutionRole,
      environment: {
        QDRANT_URL: props.qdrantUrl,
      },
      vpc: vpc,
      vpcSubnets: {
        subnets: subnets
      },
      securityGroups: [lambdaSecurityGroup],
      allowPublicSubnet: false
    });

    GitLoaderFunction.node.addDependency(ecrDeployment);

    /*────────────────── 3. DynamoDb for Dupilication Management ──────────────────*/
    const ContentManagementTable = new dynamodb.Table(this, 'ContentManagementTable', {
      tableName: systemName + '-content-management-table',
      partitionKey: {
        name: 'md5',
        type: dynamodb.AttributeType.STRING
      },
      sortKey: {
        name: 'repository',
        type: dynamodb.AttributeType.STRING
      },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });

    /*────────────────── 4. EventBridge カスタム Bus ────────────────*/
    const GitHubBus = new events.EventBus(this, 'GitHubBus', {
      eventBusName: systemName + '-github-custom-bus',
    });

    /*────────────────── 5. ルール：push → Lambda ───────────────────*/
    new events.Rule(this, 'OnAnyRepoPush', {
      ruleName: systemName + '-github-push-rule',
      eventBus: GitHubBus,
      eventPattern: {
        source: ['github'],
        detailType: ['push'],
      },
      targets: [
        new targets.LambdaFunction(GitLoaderFunction, {
          event: events.RuleTargetInput.fromObject({
            repository: events.EventField.fromPath('$.detail.repo'),
            commitId: events.EventField.fromPath('$.detail.commit'),
            branch: events.EventField.fromPath('$.detail.branch'),
          }),
        }),
      ],
    });

    /*────────────────── 6. GitHub OIDC プロバイダー ────────────────*/
    const githubProvider = new iam.OpenIdConnectProvider(this, 'GitHubOIDC', {
      url: 'https://token.actions.githubusercontent.com',
      clientIds: ['sts.amazonaws.com']
    });

    /*────────────────── 7. GitHub Actions 用ロール ────────────────*/
    const GitHubOidcRole = new iam.Role(this, 'GitHubOidcRole', {
      roleName: systemName + '-github-put-eventbridge-role',
      assumedBy: new iam.WebIdentityPrincipal(
        githubProvider.openIdConnectProviderArn,
        {
          StringEquals: {
            'token.actions.githubusercontent.com:aud': 'sts.amazonaws.com'
          },
          StringLike: {
            'token.actions.githubusercontent.com:sub': 'repo:kosakt/*:*',
          },
        },
      ),
    });

    GitHubOidcRole.addToPolicy(
      new iam.PolicyStatement({
        actions: ['events:PutEvents'],
        resources: [GitHubBus.eventBusArn],
      }),
    );

    /*────────────────── 8. 出力 ──────────────────────────────────*/
    new cdk.CfnOutput(this, 'GitHubActionsRoleArn', {
      value: GitHubOidcRole.roleArn,
      description: 'Set this as role-to-assume in your GitHub Actions workflow',
    });
  }
}
