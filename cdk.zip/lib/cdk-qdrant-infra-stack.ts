// lib/cdk-qdrant-infra-stack.ts
import * as cdk from 'aws-cdk-lib';
import { Stack, StackProps, CfnOutput } from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { RemovalPolicy } from "aws-cdk-lib";
import { DockerImageAsset, Platform } from "aws-cdk-lib/aws-ecr-assets";
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as eksv2 from '@aws-cdk/aws-eks-v2-alpha';
import * as eks from 'aws-cdk-lib/aws-eks';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as ecr from "aws-cdk-lib/aws-ecr";
import * as ecrdeploy from "cdk-ecr-deployment";
import * as path from 'path';
import { KubectlV32Layer } from '@aws-cdk/lambda-layer-kubectl-v32';

export interface InfraStackProps extends StackProps {
  vpcId: string;
  privateSubnetIds: string[];
  publicSubnetIds: string[];
  resourcePrefix: string;
  clusterName: string;
  systemName: string;
  adminPrincipalArn: string;
}

export class CdkQdrantInfraStack extends Stack {
  public readonly albSecurityGroup: ec2.SecurityGroup;
  public readonly cluster: eksv2.Cluster;
  public readonly lbcAddon: eks.CfnAddon;
  public readonly ecrRepository: ecr.Repository;
  public readonly ecrDeployment: ecrdeploy.ECRDeployment;
  public readonly ebsCsiAddon: eks.CfnAddon;

  constructor(scope: Construct, id: string, props: InfraStackProps) {
    super(scope, id, props);

    const systemName = props.systemName.toLowerCase();

    // ECR Repository
    this.ecrRepository = new ecr.Repository(this, `qdrant-repo-${systemName}${props.resourcePrefix}`, {
      repositoryName: `qdrant-repository-${systemName}${props.resourcePrefix}`,
      removalPolicy: RemovalPolicy.DESTROY,
      lifecycleRules: [{
        rulePriority: 1,
        description: "Delete untagged images older than 30 days",
        maxImageAge: cdk.Duration.days(30),
        tagStatus: ecr.TagStatus.UNTAGGED
      }, {
        rulePriority: 2,
        description: "Keep only the last 2 images with 'latest' tag",
        maxImageCount: 2,
        tagPrefixList: ['latest']
      }]
    });

    // Docker image build and push
    const asset = new DockerImageAsset(this, `qdrant-dockerimageAsset-${systemName}`, {
      directory: path.join(__dirname, "..", "qdrant"),
      platform: Platform.LINUX_AMD64,
    });

    this.ecrDeployment = new ecrdeploy.ECRDeployment(this, `qdrant-imagedeploy-${systemName}`, {
      src: new ecrdeploy.DockerImageName(asset.imageUri),
      dest: new ecrdeploy.DockerImageName(`${cdk.Aws.ACCOUNT_ID}.dkr.ecr.${cdk.Aws.REGION}.amazonaws.com/${this.ecrRepository.repositoryName}:latest`),
    });

    // VPC
    const vpc = ec2.Vpc.fromLookup(this, 'Vpc', { vpcId: props.vpcId });

    // Cluster IAM role
    const clusterRole = new iam.Role(this, `${props.resourcePrefix}-eks-cluster-role`, {
      roleName: `${props.resourcePrefix}-eks-cluster-role`,
      assumedBy: new iam.ServicePrincipal('eks.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSClusterPolicy'),
      ],
    });

    const nodeGroupRole = new iam.Role(this, `${props.resourcePrefix}-eks-nodegroup-role`, {
      roleName: `${props.resourcePrefix}-eks-nodegroup-role`,
      assumedBy: new iam.ServicePrincipal('ec2.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSWorkerNodePolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKS_CNI_Policy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEC2ContainerRegistryReadOnly'),
      ],
    });

    // EKS Cluster (Auto Mode)
    const kubectl = new KubectlV32Layer(this, `${props.resourcePrefix}-kubectl-v32`);

    this.cluster = new eksv2.Cluster(this, `${props.resourcePrefix}-cluster`, {
      clusterName: props.clusterName + props.resourcePrefix,
      version: eksv2.KubernetesVersion.V1_32,
      role: clusterRole,
      kubectlProviderOptions: { kubectlLayer: kubectl },
      vpc: vpc,
      vpcSubnets: [
        {
          subnets: props.privateSubnetIds.map(
            (id, i) => ec2.Subnet.fromSubnetId(this, `PrivateSubnet${i}`, id),
          ),
        },
        {
          subnets: props.publicSubnetIds.map(
            (id, i) => ec2.Subnet.fromSubnetId(this, `PublicSubnet${i}`, id),
          ),
        },
      ],
      defaultCapacityType: eksv2.DefaultCapacityType.AUTOMODE,
      compute: {
        nodeRole: nodeGroupRole,
      },
    });

    const adminEntry = new eks.CfnAccessEntry(this, 'AdminSsoAccessEntry', {
      clusterName: this.cluster.clusterName,
      principalArn: props.adminPrincipalArn,
      type: 'STANDARD',
      accessPolicies: [{
        policyArn: 'arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy',
        accessScope: { type: 'cluster' },
      }],
    });
    adminEntry.node.addDependency(this.cluster);

    // ALB Security Group
    this.albSecurityGroup = new ec2.SecurityGroup(this, 'AlbSecurityGroup', {
      vpc,
      description: 'Allow VPC internal access to ALB',
      allowAllOutbound: true,
    });

    // Allow VPC internal access only
    this.albSecurityGroup.addIngressRule(
      ec2.Peer.ipv4(vpc.vpcCidrBlock),
      ec2.Port.tcp(80)
    );

    // ALB to Qdrant communication
    this.cluster.clusterSecurityGroup.addIngressRule(
      this.albSecurityGroup,
      ec2.Port.tcp(6333),
      'Allow ALB to reach Qdrant HTTP port'
    );
    this.cluster.clusterSecurityGroup.addIngressRule(
      this.albSecurityGroup,
      ec2.Port.tcp(6334),
      'Allow ALB to reach Qdrant gRPC port'
    );

    // Control-plane → Webhook 9443 (needed for ALB Controller webhook)
    this.cluster.clusterSecurityGroup.addIngressRule(
      this.cluster.clusterSecurityGroup,
      ec2.Port.tcp(9443),
      'Permit API server to reach ALB controller webhook (9443)',
    );

    // ServiceAccount for ALB Controller (still needed in AutoMode for permissions)
    const albSa = this.cluster.addServiceAccount('AlbCtrlSA', {
      name: 'aws-load-balancer-controller',
      namespace: 'kube-system',
    });

    // Use Pod Identity for ALB Controller
    const albControllerPolicy = new iam.PolicyDocument({
      statements: [
        new iam.PolicyStatement({
          actions: [
            'ec2:DescribeAvailabilityZones',
            'ec2:DescribeInstances',
            'ec2:DescribeSecurityGroups',
            'ec2:DescribeSubnets',
            'ec2:DescribeTags',
            'ec2:DescribeVpcs',
            'ec2:AuthorizeSecurityGroupIngress',
            'ec2:CreateSecurityGroup',
            'ec2:CreateTags',
            'ec2:DeleteSecurityGroup',
            'ec2:DeleteTags',
            'ec2:RevokeSecurityGroupIngress',
            'elasticloadbalancing:*',
            'iam:CreateServiceLinkedRole',
            'iam:GetServerCertificate',
            'iam:ListServerCertificates',
            'cognito-idp:DescribeUserPoolClient',
            'waf-regional:GetWebACLForResource',
            'waf-regional:GetWebACL',
            'waf-regional:AssociateWebACL',
            'waf-regional:DisassociateWebACL',
            'wafv2:GetWebACL',
            'wafv2:GetWebACLForResource',
            'wafv2:AssociateWebACL',
            'wafv2:DisassociateWebACL',
            'shield:DescribeProtection',
            'shield:GetSubscriptionState',
            'shield:DeleteProtection',
            'shield:CreateProtection',
            'shield:DescribeSubscription',
            'shield:ListProtections'
          ],
          resources: ['*'],
        })
      ]
    });

    albSa.role.attachInlinePolicy(new iam.Policy(this, 'ALBControllerPolicy', {
      document: albControllerPolicy,
    }));

    // Helm: AWS Load Balancer Controller (still required as it's not available as add-on)
    const albChart = this.cluster.addHelmChart('AlbControllerChart', {
      chart: 'aws-load-balancer-controller',
      repository: 'https://aws.github.io/eks-charts',
      namespace: 'kube-system',
      wait: true,
      values: {
        clusterName: this.cluster.clusterName,
        region: this.region,
        vpcId: vpc.vpcId,
        serviceAccount: { create: false, name: albSa.serviceAccountName },
        image: {
          repository: `602401143452.dkr.ecr.${this.region}.amazonaws.com/amazon/aws-load-balancer-controller`,
        },
        defaultTags: {
          'kubernetes.io/ingress.class': 'alb',
          'alb.ingress.kubernetes.io/scheme': 'internal'
        },
        ingressClass: 'alb',
        config: {
          defaultTargetType: 'ip'
        }
      },
    });
    albChart.node.addDependency(this.cluster, albSa, this.albSecurityGroup);

    // Store reference for compatibility
    this.lbcAddon = albChart as any;  // Type assertion for compatibility

    // EBS CSI Driver Add-on
    this.ebsCsiAddon = new eks.CfnAddon(this, 'EbsCsiDriverAddon', {
      clusterName: this.cluster.clusterName,
      addonName: 'aws-ebs-csi-driver',
      resolveConflicts: 'OVERWRITE',
    });
    this.ebsCsiAddon.node.addDependency(this.cluster);

    // Outputs
    new CfnOutput(this, 'ClusterName', { value: this.cluster.clusterName });
    new CfnOutput(this, 'AlbSecurityGroupId', { value: this.albSecurityGroup.securityGroupId });
    new CfnOutput(this, 'EcrRepositoryUri', { value: this.ecrRepository.repositoryUri });
  }
}