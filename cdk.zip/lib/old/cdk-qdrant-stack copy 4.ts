import { Construct } from 'constructs';
import { RemovalPolicy } from "aws-cdk-lib";
import { KubectlV32Layer } from '@aws-cdk/lambda-layer-kubectl-v32';
import { DockerImageAsset, Platform } from "aws-cdk-lib/aws-ecr-assets";
import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as eks from '@aws-cdk/aws-eks-v2-alpha';
import * as ecr from "aws-cdk-lib/aws-ecr";
import * as ecrdeploy from "cdk-ecr-deployment";
import * as path from "path";


export interface QdrantEksStackProps extends cdk.StackProps {
  acmArn?: string;
  isPublic: boolean;
  vpcId: string;
  availabilityZones: string[];
  publicSubnetIds: string[];
  privateSubnetIds: string[];
  vpcCidr?: string; // オプションに変更
  systemName: string;

  // リソース名設定
  resourcePrefix: string;
  clusterName?: string;
  nodeGroupName?: string;

  // EKS設定
  kubernetesVersion?: eks.KubernetesVersion;
  instanceTypes?: ec2.InstanceType[];
  minSize?: number;
  maxSize?: number;
  desiredSize?: number;

  ecrRepositoryUri?: string;
  qdrantImageTag?: string;

  qdrantCpuLimit?: number;
  qdrantMemoryLimit?: number;
  qdrantReplicas?: number;

  qdrantCpuRequest?: number;
  qdrantMemoryRequest?: string;

}

export class CdkQdrantStack extends cdk.Stack {
  public readonly cluster: eks.Cluster;
  public readonly vpc: ec2.IVpc;

  public readonly albSecurityGroup: ec2.SecurityGroup;
  public readonly appSecurityGroup: ec2.SecurityGroup;
  public readonly ecrRepository: ecr.Repository;

  public readonly loadBalancerControllerRole: iam.IRole;
  private readonly finalImageUri: string;

  private helmChart!: eks.HelmChart;

  constructor(scope: Construct, id: string, props: QdrantEksStackProps) {

    super(scope, id, props);

    // デフォルト値の設定
    const resourcePrefix = props.resourcePrefix;
    const clusterName = props.clusterName || `${resourcePrefix}-qdrant-cluster`;

    // VPCの取得
    this.vpc = this.Vpc(props, resourcePrefix);

    // セキュリティグループの作成（VPC取得後）
    const securityGroups = this.createSecurityGroups(resourcePrefix, props);
    this.albSecurityGroup = securityGroups.albSG;
    this.appSecurityGroup = securityGroups.appSG;

    // コンテナレポジトリの作成
    const containerRepo = this.createContainerRepo(resourcePrefix, props);
    this.ecrRepository = containerRepo.ecrRepo;
    this.finalImageUri = containerRepo.imageUri;

    // 管理者ロールARNの定義
    const adminSsoRoleArn = `arn:aws:iam::${cdk.Aws.ACCOUNT_ID}:role/aws-reserved/sso.amazonaws.com/ap-northeast-1/AWSReservedSSO_AdministratorAccess_53ea33b610176220`;

    // Auto Mode有効のEKSクラスターの作成
    this.cluster = this.createEksCluster(clusterName, resourcePrefix, props);

    // コンテナレポジトリに権限を付与
    this.ecrRepository.grantPull(this.cluster.role);

    // アクセスエントリの作成
    const adminAccessEntry = new cdk.aws_eks.CfnAccessEntry(this, 'AdminSsoAccessEntry', {
      clusterName: this.cluster.clusterName,
      principalArn: adminSsoRoleArn,
      type: 'STANDARD',
      accessPolicies: [{
        policyArn: 'arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy',
        accessScope: {
          type: 'cluster',
        },
      }],
    });
    adminAccessEntry.node.addDependency(this.cluster);

    // Kubernetes内でのClusterRoleBindingを追加
    this.cluster.addManifest('SsoAdminClusterRoleBinding', {
      apiVersion: 'rbac.authorization.k8s.io/v1',
      kind: 'ClusterRoleBinding',
      metadata: {
        name: 'sso-admin-cluster-admin'
      },
      roleRef: {
        apiGroup: 'rbac.authorization.k8s.io',
        kind: 'ClusterRole',
        name: 'cluster-admin'
      },
      subjects: [{
        kind: 'User',
        name: adminSsoRoleArn,
        apiGroup: 'rbac.authorization.k8s.io'
      }]
    });

    // ロードバランサ管理ロールの作成
    this.loadBalancerControllerRole = this.createLoadBalancerController(resourcePrefix);

    // CDK実行後に手動でポリシーを関連付けるためのコマンドを出力
    new cdk.CfnOutput(this, 'AssociateSsoAdminPolicyCommand', {
      value: `aws eks associate-access-policy --cluster-name ${this.cluster.clusterName} --principal-arn ${adminSsoRoleArn} --policy-arn arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy --access-scope type=cluster`,
      description: 'Command to associate admin policy with SSO role',
    });

    // AWS Load Balancer Controller完了後にQdrantリソースをデプロイ
    this.deployQdrantManifests(resourcePrefix, props);

    // Outputとして出力
    this.createOutputs(clusterName);
  }

  // 既存VPCの読み込み
  private Vpc(props: QdrantEksStackProps, resourcePrefix: string): ec2.IVpc {
    return ec2.Vpc.fromLookup(this, `${resourcePrefix}-vpc`, {
      vpcId: props.vpcId
    });
  }

  // ALB用セキュリティグループ（albSG）と アプリケーション用セキュリティグループ（appSG）の作成
  private createSecurityGroups(resourcePrefix: string, props: QdrantEksStackProps): { albSG: ec2.SecurityGroup; appSG: ec2.SecurityGroup } {

    // ALB用セキュリティグループの作成
    const albSG = new ec2.SecurityGroup(this, `${resourcePrefix}-alb-sg`, {
      vpc: this.vpc,
      securityGroupName: `${resourcePrefix}-alb-sg`,
      description: 'Security group for Qdrant ALB',
      allowAllOutbound: true
    });

    // アプリケーション用セキュリティグループの作成
    const appSG = new ec2.SecurityGroup(this, `${resourcePrefix}-app-sg`, {
      vpc: this.vpc,
      securityGroupName: `${resourcePrefix}-app-sg`,
      description: 'Security group for Qdrant application',
      allowAllOutbound: true
    });

    // ALBセキュリティグループへのルール追加
    albSG.addIngressRule(
      ec2.Peer.anyIpv4(),
      ec2.Port.tcp(443),
      'HTTPS access from internet'
    );

    albSG.addIngressRule(
      ec2.Peer.anyIpv4(),
      ec2.Port.tcp(80),
      'HTTP access from internet (redirect to HTTPS)'
    );

    // アプリケーションセキュリティグループへのルール追加
    appSG.addIngressRule(
      ec2.Peer.securityGroupId(albSG.securityGroupId),
      ec2.Port.tcp(6333),
      'Qdrant HTTP API access from ALB'
    );

    // ALBからQdrant gRPCへのアクセス許可
    appSG.addIngressRule(
      ec2.Peer.securityGroupId(albSG.securityGroupId),
      ec2.Port.tcp(6334),
      'Qdrant gRPC API access from ALB'
    );

    // EKSクラスター内通信（VPCのCIDRを動的に取得）
    const vpcCidr = props.vpcCidr || this.vpc.vpcCidrBlock;
    if (vpcCidr && vpcCidr !== '') {
      appSG.addIngressRule(
        ec2.Peer.ipv4(vpcCidr),
        ec2.Port.allTraffic(),
        'EKS cluster internal communication'
      );
    } else {
      // CIDRが取得できない場合は、プライベートサブネットからのアクセスのみ許可
      console.warn('VPC CIDR not available, using alternative security group rules');
      appSG.addIngressRule(
        ec2.Peer.ipv4('172.16.0.0/22'),
        ec2.Port.allTraffic(),
        'EKS cluster internal communication'
      );
    }
    return { albSG, appSG };
  }

  // ライフサイクルを含む ECR レポジトリ構成
  private createContainerRepo(resourcePrefix: string, props: QdrantEksStackProps): { ecrRepo: ecr.Repository; imageUri: string } {
    const ecrRepo = new ecr.Repository(this, "qdrant-repo-" + resourcePrefix, {
      repositoryName: "qdrant-repository-" + resourcePrefix,
      removalPolicy: RemovalPolicy.DESTROY,
      lifecycleRules: [{
        rulePriority: 1,
        description: "Delete untagged images older than 30 days, exclude 'latest'",
        maxImageAge: cdk.Duration.days(30),
        tagStatus: ecr.TagStatus.UNTAGGED
      }, {
        rulePriority: 2,
        description: "Keep only the last 2 images with 'latest' tag",
        maxImageCount: 2,
        tagPrefixList: ['latest']
      }]
    });

    const imageTag = props.qdrantImageTag || 'latest';

    const asset = new DockerImageAsset(this, "qdrant-dockerimageAsset-" + resourcePrefix, {
      directory: path.join(__dirname, "..", "qdrant-docker"),
      platform: Platform.LINUX_AMD64,
    });

    // ECR イメージの登録
    const deployment = new ecrdeploy.ECRDeployment(this, "qdrant-imagedeploy-" + resourcePrefix, {
      src: new ecrdeploy.DockerImageName(asset.imageUri),
      dest: new ecrdeploy.DockerImageName(`${cdk.Aws.ACCOUNT_ID}.dkr.ecr.${cdk.Aws.REGION}.amazonaws.com/${ecrRepo.repositoryName}:latest`),
    });

    deployment.node.addDependency(ecrRepo);

    return {
      ecrRepo,
      imageUri: `${ecrRepo.repositoryUri}:${props.qdrantImageTag || 'latest'}`
    };

  }

  // EKS クラスタを自動モードを有効にして作成
  private createEksCluster(
    clusterName: string,
    resourcePrefix: string,
    props: QdrantEksStackProps
  ): eks.Cluster {

    // EKS クラスタのロールを作成
    const clusterRole = new iam.Role(this, `${resourcePrefix}-cluster-role`, {
      roleName: `${resourcePrefix}-eks-cluster-role`,
      assumedBy: new iam.ServicePrincipal('eks.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSClusterPolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSBlockStoragePolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSComputePolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSLoadBalancingPolicy'),
        iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEKSNetworkingPolicy'),
      ],
    });

    // EKS クラスタのロールポリシーを追加
    clusterRole.assumeRolePolicy!.addStatements(
      new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        principals: [new iam.ServicePrincipal('eks.amazonaws.com')],
        actions: ['sts:AssumeRole', 'sts:TagSession'],
      }),
    );

    // クラスターロールにECR権限を追加
    clusterRole.addToPolicy(new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        'ecr:GetAuthorizationToken',
        'ecr:BatchCheckLayerAvailability',
        'ecr:GetDownloadUrlForLayer',
        'ecr:BatchGetImage'
      ],
      resources: ['*']
    }));

    const kubectl = new KubectlV32Layer(this, `${resourcePrefix}-kubectl-v32`);

    // EKS Auto Modeクラスターの作成
    const cluster = new eks.Cluster(this, `${resourcePrefix}-cluster`, {
      clusterName: clusterName,
      kubectlProviderOptions: {
        kubectlLayer: kubectl,
      },
      version: props.kubernetesVersion || eks.KubernetesVersion.V1_32,
      role: clusterRole,
      vpc: this.vpc,
      vpcSubnets: [
        {
          subnets: props.privateSubnetIds.map((subnetId, index) =>
            ec2.Subnet.fromSubnetAttributes(this, `PrivateSubnet${index}`, {
              subnetId
            }),
          ),
        },
      ],
      endpointAccess: eks.EndpointAccess.PUBLIC_AND_PRIVATE,
      clusterLogging: [
        eks.ClusterLoggingTypes.API,
        eks.ClusterLoggingTypes.AUDIT,
        eks.ClusterLoggingTypes.AUTHENTICATOR,
        eks.ClusterLoggingTypes.CONTROLLER_MANAGER,
        eks.ClusterLoggingTypes.SCHEDULER,
      ],
      defaultCapacityType: eks.DefaultCapacityType.AUTOMODE,
      tags: {
        System: props.systemName
      }
    });

    return cluster;
  }

  private createLoadBalancerController(resourcePrefix: string): iam.IRole {
    // ServiceAccount を作成（CDKが自動的にOIDC設定を処理）
    const serviceAccount = this.cluster.addServiceAccount('aws-load-balancer-controller', {
      name: 'aws-load-balancer-controller',
      namespace: 'kube-system'
    });

    // 必要な権限を追加
    serviceAccount.addToPrincipalPolicy(
      new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        actions: [
          'iam:CreateServiceLinkedRole',
          'ec2:DescribeAccountAttributes',
          'ec2:DescribeAddresses',
          'ec2:DescribeAvailabilityZones',
          'ec2:DescribeInternetGateways',
          'ec2:DescribeVpcs',
          'ec2:DescribeVpcPeeringConnections',
          'ec2:DescribeSubnets',
          'ec2:DescribeSecurityGroups',
          'ec2:DescribeInstances',
          'ec2:DescribeNetworkInterfaces',
          'ec2:DescribeTags',
          'ec2:GetCoipPoolUsage',
          'ec2:DescribeCoipPools',
          'elasticloadbalancing:*',
          'iam:PassRole',
          'iam:GetRole',
          'iam:ListRolePolicies',
          'iam:ListAttachedRolePolicies',
          'cognito-idp:DescribeUserPoolClient',
          'acm:ListCertificates',
          'acm:DescribeCertificate',
          'iam:ListServerCertificates',
          'iam:GetServerCertificate',
          'waf-regional:GetWebACL',
          'waf-regional:GetWebACLForResource',
          'waf-regional:AssociateWebACL',
          'waf-regional:DisassociateWebACL',
          'wafv2:GetWebACL',
          'wafv2:GetWebACLForResource',
          'wafv2:AssociateWebACL',
          'wafv2:DisassociateWebACL',
          'shield:DescribeProtection',
          'shield:GetSubscriptionState',
          'shield:DescribeSubscription',
          'shield:CreateProtection',
          'shield:DeleteProtection'
        ],
        resources: ['*']
      })
    );

    // Helm Chart でのインストール
    this.helmChart = this.cluster.addHelmChart('AWSLoadBalancerController', {
      chart: 'aws-load-balancer-controller',
      repository: 'https://aws.github.io/eks-charts',
      namespace: 'kube-system',
      wait: true,
      values: {
        clusterName: this.cluster.clusterName,
        serviceAccount: {
          create: false,
          name: 'aws-load-balancer-controller'
        },
        region: cdk.Aws.REGION,
        vpcId: this.vpc.vpcId,
        image: {
          repository: `602401143452.dkr.ecr.${cdk.Aws.REGION}.amazonaws.com/amazon/aws-load-balancer-controller`
        }
      }
    });

    // 依存関係を明確に設定
    this.helmChart.node.addDependency(serviceAccount);

    return serviceAccount.role;
  }

  // QdrantManifestsの作成
  private deployQdrantManifests(resourcePrefix: string, props: QdrantEksStackProps) {
    // AWS Load Balancer Controller の準備ができるまで待機するためのJob
    const controllerReadinessCheck = this.cluster.addManifest('LoadBalancerControllerReadinessCheck', {
      apiVersion: 'batch/v1',
      kind: 'Job',
      metadata: {
        name: 'alb-controller-readiness-check',
        namespace: 'kube-system'
      },
      spec: {
        template: {
          spec: {
            restartPolicy: 'Never',
            containers: [{
              name: 'readiness-check',
              image: 'bitnami/kubectl:latest',
              command: [
                'sh',
                '-c',
                `
                echo "Waiting for AWS Load Balancer Controller to be ready..."
                for i in $(seq 1 60); do
                  if kubectl get deployment -n kube-system aws-load-balancer-controller; then
                    kubectl wait --for=condition=available --timeout=300s deployment/aws-load-balancer-controller -n kube-system
                    if [ $? -eq 0 ]; then
                      echo "AWS Load Balancer Controller is ready"
                      exit 0
                    fi
                  fi
                  echo "Waiting... ($i/60)"
                  sleep 10
                done
                echo "Timeout waiting for AWS Load Balancer Controller"
                exit 1
                `
              ]
            }],
            serviceAccountName: 'default'
          }
        }
      }
    });

    // Readiness check完了後にQdrantリソースをデプロイ
    this.deployQdrantInline(resourcePrefix, props, controllerReadinessCheck);
  }

  // deployQdrantInlineの作成
  private deployQdrantInline(
    resourcePrefix: string,
    props: QdrantEksStackProps,
    readinessCheck: eks.KubernetesManifest
  ) {
    const namespace = 'qdrant';
    const appName = 'qdrant';
    const imageUri = props.ecrRepositoryUri || `${cdk.Aws.ACCOUNT_ID}.dkr.ecr.${cdk.Aws.REGION}.amazonaws.com/qdrant`;
    const imageTag = props.qdrantImageTag || 'latest';

    // Step1: Namespaceを最初に作成
    const namespaceManifest = this.cluster.addManifest('QdrantNamespace', {
      apiVersion: 'v1',
      kind: 'Namespace',
      metadata: {
        name: namespace,
        labels: {
          name: namespace
        }
      }
    });

    // Readiness check完了後にNamespaceを作成
    namespaceManifest.node.addDependency(readinessCheck);

    // Step2: ConfigMap、PVCを作成（Namespace作成後）
    const basicResourcesManifest = this.cluster.addManifest('QdrantBasicResources',
      // ConfigMap
      {
        apiVersion: 'v1',
        kind: 'ConfigMap',
        metadata: {
          name: `${appName}-config`,
          namespace: namespace
        },
        data: {
          'QDRANT__SERVICE__HTTP_PORT': '6333',
          'QDRANT__SERVICE__GRPC_PORT': '6334',
          'QDRANT__LOG_LEVEL': 'INFO'
        }
      },
      // PersistentVolumeClaim
      {
        apiVersion: 'v1',
        kind: 'PersistentVolumeClaim',
        metadata: {
          name: `${appName}-pvc`,
          namespace: namespace
        },
        spec: {
          accessModes: ['ReadWriteOnce'],
          storageClassName: 'gp3',
          resources: {
            requests: {
              storage: '10Gi'
            }
          }
        }
      }
    );

    // Namespace作成後に基本リソースを作成するよう依存関係を設定
    basicResourcesManifest.node.addDependency(namespaceManifest);

    // Step3: Deploymentを作成（基本リソース作成後）
    const deploymentManifest = this.cluster.addManifest('QdrantDeployment', {
      apiVersion: 'apps/v1',
      kind: 'Deployment',
      metadata: {
        name: `${appName}-deployment`,
        namespace: namespace,
        labels: {
          app: appName
        }
      },
      spec: {
        replicas: props.qdrantReplicas || 2,
        strategy: {
          type: 'RollingUpdate',
          rollingUpdate: {
            maxUnavailable: 1,
            maxSurge: 1
          }
        },
        selector: {
          matchLabels: {
            app: appName
          }
        },
        template: {
          metadata: {
            labels: {
              app: appName
            }
          },
          spec: {
            affinity: {
              podAntiAffinity: {
                preferredDuringSchedulingIgnoredDuringExecution: [{
                  weight: 100,
                  podAffinityTerm: {
                    labelSelector: {
                      matchExpressions: [{
                        key: 'app',
                        operator: 'In',
                        values: [appName]
                      }]
                    },
                    topologyKey: 'kubernetes.io/hostname'
                  }
                }]
              }
            },
            containers: [{
              name: appName,
              image: `${imageUri}:${imageTag}`,
              ports: [
                { containerPort: 6333, name: 'http' },
                { containerPort: 6334, name: 'grpc' }
              ],
              envFrom: [{
                configMapRef: {
                  name: `${appName}-config`
                }
              }],
              volumeMounts: [{
                name: 'qdrant-storage',
                mountPath: '/qdrant/storage'
              }],
              securityContext: {
                runAsNonRoot: true,
                runAsUser: 1000,
                allowPrivilegeEscalation: false,
                capabilities: {
                  drop: ['ALL']
                }
              },
              startupProbe: {
                httpGet: {
                  path: '/health',
                  port: 6333
                },
                initialDelaySeconds: 10,
                periodSeconds: 10,
                failureThreshold: 30
              },
              livenessProbe: {
                httpGet: {
                  path: '/health',
                  port: 6333
                },
                initialDelaySeconds: 30,
                periodSeconds: 10
              },
              readinessProbe: {
                httpGet: {
                  path: '/readiness',
                  port: 6333
                },
                initialDelaySeconds: 5,
                periodSeconds: 5
              },
              resources: {
                limits: {
                  cpu: props.qdrantCpuLimit || '1000m',
                  memory: props.qdrantMemoryLimit || '2Gi'
                },
                requests: {
                  cpu: props.qdrantCpuRequest || '500m',
                  memory: props.qdrantMemoryRequest || '1Gi'
                }
              }
            }],
            volumes: [{
              name: 'qdrant-storage',
              persistentVolumeClaim: {
                claimName: `${appName}-pvc`
              }
            }]
          }
        }
      }
    });
    // 基本リソース作成後にDeploymentを作成するよう依存関係を設定
    deploymentManifest.node.addDependency(basicResourcesManifest);

    // Step4: ServiceとIngressを別々に作成（Deployment作成後）
    const serviceManifest = this.cluster.addManifest('QdrantService', {
      apiVersion: 'v1',
      kind: 'Service',
      metadata: {
        name: `${appName}-service`,
        namespace: namespace,
        labels: {
          app: appName
        }
      },
      spec: {
        selector: {
          app: appName
        },
        ports: [
          {
            name: 'http',
            protocol: 'TCP',
            port: 6333,
            targetPort: 6333
          },
          {
            name: 'grpc',
            protocol: 'TCP',
            port: 6334,
            targetPort: 6334
          }
        ],
        type: 'ClusterIP'
      }
    });

    serviceManifest.node.addDependency(deploymentManifest);

    // Step5: Ingressを作成（Service作成後）
    const ingressManifest = this.cluster.addManifest('QdrantIngress', {
      apiVersion: 'networking.k8s.io/v1',
      kind: 'Ingress',
      metadata: {
        name: `${appName}-ingress`,
        namespace: namespace,
        annotations: {
          'kubernetes.io/ingress.class': 'alb',
          'alb.ingress.kubernetes.io/scheme': 'internet-facing',
          'alb.ingress.kubernetes.io/target-type': 'ip',
          'alb.ingress.kubernetes.io/subnets': props.publicSubnetIds.join(','),
          'alb.ingress.kubernetes.io/security-groups': this.albSecurityGroup.securityGroupId,
          'alb.ingress.kubernetes.io/certificate-arn': props.acmArn,
          'alb.ingress.kubernetes.io/listen-ports': '[{"HTTPS":443}, {"HTTP":80}]',
          'alb.ingress.kubernetes.io/ssl-redirect': '443',
          'alb.ingress.kubernetes.io/healthcheck-path': '/health',
          'alb.ingress.kubernetes.io/healthcheck-interval-seconds': '15',
          'alb.ingress.kubernetes.io/healthcheck-timeout-seconds': '5',
          'alb.ingress.kubernetes.io/success-codes': '200',
          'alb.ingress.kubernetes.io/healthy-threshold-count': '2',
          'alb.ingress.kubernetes.io/unhealthy-threshold-count': '2',
          'alb.ingress.kubernetes.io/tags': `Environment=${resourcePrefix},Application=qdrant`
        }
      },
      spec: {
        rules: [{
          http: {
            paths: [{
              path: '/',
              pathType: 'Prefix',
              backend: {
                service: {
                  name: `${appName}-service`,
                  port: {
                    number: 6333
                  }
                }
              }
            }]
          }
        }]
      }
    });

    // Service作成後にIngressを作成するよう依存関係を設定
    ingressManifest.node.addDependency(serviceManifest);

    // ALB Controllerの準備完了までIngress作成を待機させる 
    ingressManifest.node.addDependency(this.helmChart);

  }

  private createHorizontalPodAutoscaler(resourcePrefix: string) {
    this.cluster.addManifest('QdrantHPA', {
      apiVersion: 'autoscaling/v2',
      kind: 'HorizontalPodAutoscaler',
      metadata: {
        name: 'qdrant-hpa',
        namespace: 'qdrant'
      },
      spec: {
        scaleTargetRef: {
          apiVersion: 'apps/v1',
          kind: 'Deployment',
          name: 'qdrant-deployment'
        },
        minReplicas: 2,
        maxReplicas: 10,
        metrics: [
          {
            type: 'Resource',
            resource: {
              name: 'cpu',
              target: {
                type: 'Utilization',
                averageUtilization: 70
              }
            }
          },
          {
            type: 'Resource',
            resource: {
              name: 'memory',
              target: {
                type: 'Utilization',
                averageUtilization: 80
              }
            }
          }
        ]
      }
    });
  }

  // ServiceMonitor for Prometheus (if using)
  private setupMonitoring(resourcePrefix: string) {
    this.cluster.addManifest('QdrantServiceMonitor', {
      apiVersion: 'monitoring.coreos.com/v1',
      kind: 'ServiceMonitor',
      metadata: {
        name: 'qdrant-metrics',
        namespace: 'qdrant',
        labels: {
          app: 'qdrant'
        }
      },
      spec: {
        selector: {
          matchLabels: {
            app: 'qdrant'
          }
        },
        endpoints: [{
          port: 'http',
          path: '/metrics'
        }]
      }
    });
  }

  // CDKで作成したリソースを出力
  private createOutputs(clusterName: string) {
    new cdk.CfnOutput(this, 'ClusterName', {
      value: clusterName,
      description: 'EKS Cluster Name',
    });

    new cdk.CfnOutput(this, 'ClusterEndpoint', {
      value: this.cluster.clusterEndpoint,
      description: 'EKS Cluster Endpoint',
    });

    new cdk.CfnOutput(this, 'ALBSecurityGroupId', {
      value: this.albSecurityGroup.securityGroupId,
      description: 'ALB Security Group ID',
    });

    new cdk.CfnOutput(this, 'AppSecurityGroupId', {
      value: this.appSecurityGroup.securityGroupId,
      description: 'Application Security Group ID',
    });

    new cdk.CfnOutput(this, 'ECRRepositoryUri', {
      value: this.ecrRepository.repositoryUri,
      description: 'ECR Repository URI',
    });

    new cdk.CfnOutput(this, 'KubectlCommand', {
      value: `aws eks update-kubeconfig --region ${cdk.Aws.REGION} --name ${clusterName}`,
      description: 'Command to configure kubectl',
    });

    new cdk.CfnOutput(this, 'CheckResourcesCommand', {
      value: 'kubectl get all -n qdrant',
      description: 'Command to check Qdrant resources',
    });

    // Load Balancer Controller確認用コマンド
    new cdk.CfnOutput(this, 'CheckLoadBalancerControllerCommand', {
      value: 'kubectl get deployment -n kube-system aws-load-balancer-controller',
      description: 'Command to check AWS Load Balancer Controller status',
    });
  }
}