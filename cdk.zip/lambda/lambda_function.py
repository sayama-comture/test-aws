import boto3
from datetime import datetime, timezone, timedelta
import hashlib
import json
import logging
import os
import shutil
import uuid

from langchain_community.document_loaders import GitLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from qdrant_client.models import VectorParams, Distance, PointStruct, Filter, FieldCondition, MatchValue
import qdrant_client

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# 使用する環境変数の取得
url = os.environ.get("QDRANT_URL", "localhost")
table_name = os.environ.get("MANAGEMENT_TABLE")

# qdrantクライアントの初期化
client = qdrant_client.QdrantClient(url=url, port=6333)

# boto3クライアントの初期化
dynamodb = boto3.resource('dynamodb')
bedrock_client = boto3.client(
    'bedrock-runtime',
    region_name='us-east-1'
)

# 処理するファイルのプレフィックス一覧
supported_extensions = [
    'py', 'js', 'ts', 'java', 'cpp', 'c', 'h', 'hpp',
    'cs', 'php', 'rb', 'go', 'rs', 'kt', 'swift',
    'scala', 'clj', 'sh', 'sql', 'r', 'm', 'lua','tsx'
]

# JST（UTC+9）を定義
jst = timezone(timedelta(hours=9))

# ファイルの変更管理をハッシュで行うクラス
class FileHashManager:
    def __init__(self, repo_name=""):
        self.table = dynamodb.Table(table_name)
        self.repo_name = repo_name
    
    def calculate_file_hash(self, file_path):
        """ファイルのSHA256ハッシュを計算"""
        hash_sha256 = hashlib.sha256()
        try:
            with open("/tmp/sample/"+file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_sha256.update(chunk)
        except Exception as e:
            logger.info(f"ハッシュ計算エラー {file_path}: {e}")
            return None
        return hash_sha256.hexdigest()
    
    def get_stored_hash(self, file_path):
        """DynamoDBから保存されているハッシュを取得"""
        try:
            response = self.table.get_item(
                Key={
                    'md5': str(file_path),
                    'repository': self.repo_name
                }
            )
        except Exception as e:
            logger.info(f"ハッシュ取得エラー {file_path}: {e}")
            return None
        if 'Item' in response:
            return response['Item']['file_hash']
        return None
    
    def store_file_hash(self, file_path, file_hash):
        """ファイルハッシュをDynamoDBに保存"""
        file_size = os.path.getsize("/tmp/sample/"+file_path)
        
        item = {
            'md5': str(file_path),
            'file_hash': file_hash,
            'last_modified': datetime.now(jst).isoformat(),
            'file_size': file_size,
            'repository': self.repo_name
        }
        
        try:
            self.table.put_item(Item=item)
            return True
        except Exception as e:
            logger.info(f"ハッシュ保存エラー {file_path}: {e}")
            return False
    
    def is_file_changed(self, file_path):
        """ファイルが変更されたかチェック"""
        current_hash = self.calculate_file_hash(file_path)
        if current_hash is None:
            logger.info(f"current_hash is none: {file_path}")
            return False, None
        
        stored_hash = self.get_stored_hash(file_path)
        
        # 新しいファイルまたはハッシュが異なる場合
        if stored_hash is None or stored_hash != current_hash:
            return True, current_hash
        return False, current_hash
    
    def get_all_stored_files(self):
        """DynamoDBからリポジトリの全ファイル情報を取得"""
        try:
            response = self.table.scan(
                FilterExpression=boto3.dynamodb.conditions.Attr('repository').eq(self.repo_name)
            )
            return {item['md5']: item for item in response['Items']}
        except Exception as e:
            logger.info(f"ファイル一覧取得エラー: {e}")
            return {}
    
    def delete_file_record(self, file_path):
        """DynamoDBからファイルレコードを削除"""
        try:
            self.table.delete_item(
                Key={
                    'md5': str(file_path),
                    'repository': self.repo_name
                }
            )
            return True
        except Exception as e:
            logger.info(f"ファイルレコード削除エラー {file_path}: {e}")
            return False


def get_embedding(text, model_id="amazon.titan-embed-text-v1"):
    """
    Amazon Titan Embeddings を使用してテキストをベクトル化する
    """
    try:
        body = json.dumps({
            "inputText": text
        })
        
        response = bedrock_client.invoke_model(
            modelId=model_id,
            body=body,
            contentType='application/json',
            accept='application/json'
        )
        
        response_body = json.loads(response['body'].read())
        return response_body['embedding']
        
    except Exception as e:
        logger.error(f"Embedding error: {e}")
        raise


def filter_changed_documents(documents, hash_manager):
    """変更されたファイルのドキュメントのみをフィルタリング"""
    changed_documents = []
    skipped = 0
    not_changed = 0
    
    # ファイルごとにハッシュをチェック
    for doc in documents:
        file_path = doc.metadata["file_path"]
        
        # 拡張子が処理対象外ならスキップ
        if str(file_path).split(".")[-1] not in supported_extensions:
            skipped += 1
            continue
        
        # DynamoDBのハッシュと比較
        is_changed, file_hash = hash_manager.is_file_changed(file_path)
        
        if is_changed:
            # ハッシュが変更されている場合、ドキュメントを処理対象に追加
            changed_documents.append(doc)
        else:
            # ハッシュが一致した場合、処理をスキップ
            logger.info(f"file_path {file_path} - not changed, skipping")
            not_changed += 1
    
    return changed_documents, skipped, not_changed


def detect_deleted_files(documents, hash_manager):
    """削除されたファイルを検知"""
    # 現在のファイル一覧を取得
    current_files = set()
    for doc in documents:
        file_path = doc.metadata["file_path"]
        if str(file_path).split(".")[-1] in supported_extensions:
            current_files.add(file_path)
    
    # DynamoDBに保存されているファイル一覧を取得
    stored_files = hash_manager.get_all_stored_files()
    stored_file_paths = set(stored_files.keys())
    
    # 削除されたファイルを特定
    deleted_files = stored_file_paths - current_files
    
    return list(deleted_files)


def remove_deleted_files_from_qdrant(collection_name, deleted_files, hash_manager):
    """削除されたファイルに対応するベクトルをQdrantから削除"""
    deleted_count = 0
    
    for file_path in deleted_files:
        try:
            # ファイルパスでフィルタリングして削除
            filter_condition = Filter(
                must=[
                    FieldCondition(
                        key="file_path",
                        match=MatchValue(value=file_path)
                    )
                ]
            )
            
            client.delete(
                collection_name=collection_name,
                points_selector=filter_condition
            )
            logger.info(f"Qdrantから削除: {file_path}")
            deleted_count += 1
            
            # DynamoDBからレコードを削除
            hash_manager.delete_file_record(file_path)
            logger.info(f"DynamoDBから削除: {file_path}")
            
        except Exception as e:
            logger.info(f"削除エラー {file_path}: {e}")
    
    return deleted_count


def delete_old_vectors_by_file_path(collection_name, file_path):
    """指定されたファイルパスの古いベクトルをQdrantから削除"""
    try:
        filter_condition = Filter(
            must=[
                FieldCondition(
                    key="file_path",
                    match=MatchValue(value=file_path)
                )
            ]
        )
        
        client.delete(
            collection_name=collection_name,
            points_selector=filter_condition
        )
        logger.info(f"古いベクトルを削除: {file_path}")
        return True
    except Exception as e:
        logger.info(f"古いベクトル削除エラー {file_path}: {e}")
        return False


def generate_unique_uuid():
    """UUID4を生成"""
    return str(uuid.uuid4())


def lambda_handler(event, context):
    logger.info("start lambda_handler")
    # レポジトリ名の取得
    repo_name = event['repository']
    repo_url = "https://github.com/" + repo_name
    
    # Gitリポジトリをクローンする
    loader = GitLoader(repo_path="/tmp/sample", clone_url=repo_url)
    documents = loader.load()
    logger.info(f"レポジトリのクローンが完了しました。: {repo_url}")
    
    # 管理クラスの初期化
    hash_manager = FileHashManager(repo_name)
    
    # コレクション名は"/"が使用できないため置換
    collection_name = repo_name.replace("/", "_")
    
    # 削除されたファイルを検知してQdrantから削除
    deleted_files = detect_deleted_files(documents, hash_manager)
    if deleted_files:
        logger.info(f"削除されたファイル数: {len(deleted_files)}")
        deleted_count = remove_deleted_files_from_qdrant(collection_name, deleted_files, hash_manager)
        logger.info(f"Qdrantから削除したファイル数: {deleted_count}")
    
    # 変更されたファイルのドキュメントのみをフィルタリング
    changed_documents, skipped, not_changed = filter_changed_documents(documents, hash_manager)
    logger.info(f"変更されたファイル数: {len(changed_documents)}, スキップ: {skipped}, 未変更: {not_changed}")
    
    # 変更されたドキュメントがない場合は処理を終了
    if not changed_documents:
        logger.info("変更されたファイルがないため、処理を終了します")
        shutil.rmtree("/tmp/sample")
        return
    
    # スプリット処理（変更されたドキュメントのみ）
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        length_function=len,
        separators=[
            "\n\n",  # 段落区切り
            "\ndef ",  # 関数定義
            "\nclass ",  # クラス定義
            "\nif ",  # if文
            "\nfor ",  # for文
            "\nwhile ",  # while文
            "\ntry:",  # try文
            "\n",  # 改行
            " ",  # スペース
            ""
        ]
    )
    split_documents = text_splitter.split_documents(changed_documents)
    
    # コレクションが存在しなければ、新規作成
    if not client.collection_exists(collection_name):
        try:
            client.create_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(
                    size=1536,  # Amazon Titan Embeddings の次元数
                    distance=Distance.COSINE
                )
            )
        except Exception as e:
            logger.error(f"コレクション作成エラー: {e}")
            raise
    
    
    # ファイルごとに処理してグループ化
    files_to_process = {}
    for doc in split_documents:
        file_path = doc.metadata["file_path"]
        if file_path not in files_to_process:
            files_to_process[file_path] = []
        files_to_process[file_path].append(doc)
    
    logger.info(f"処理対象ファイル数: {len(files_to_process)}")
    logger.info(f"保存対象ドキュメント数: {len(split_documents)}")
    
    # 変数の初期化
    stored = 0
    
    # ファイルごとに処理
    for file_path, file_docs in files_to_process.items():
        logger.info(f"処理中のファイル: {file_path} ({len(file_docs)} chunks)")
        
        # 古いベクトルを削除
        delete_old_vectors_by_file_path(collection_name, file_path)
        
        # 新しいベクトルを作成
        file_points = []
        for chunk_index, doc in enumerate(file_docs):
            try:
                # 埋め込み処理
                embedding = get_embedding(doc.page_content)
                
            except Exception as e:
                logger.info(f"埋め込み処理エラー {file_path} chunk {chunk_index}: {e}")
                continue

            # UUIDを生成
            unique_id = generate_unique_uuid()
            
            # メタデータにファイル情報とチャンクインデックスを追加
            payload = doc.metadata.copy()
            payload['chunk_index'] = chunk_index
            payload['total_chunks'] = len(file_docs)
            
            # ポイントを追加
            file_points.append(PointStruct(
                id=unique_id,
                vector=embedding,
                payload=payload
            ))
                
        # ファイルのポイントをバッチごとにQdrantに追加
        batch_size = 50
        for i in range(0, len(file_points), batch_size):
            batch_points = file_points[i:i + batch_size]
            try:
                client.upsert(
                    collection_name=collection_name,
                    points=batch_points
                )
                logger.info(f"バッチ登録完了: {file_path} - {len(batch_points)} ポイント (batch {i//batch_size + 1})")
                stored += len(batch_points)
            except Exception as e:
                logger.error(f"バッチ登録エラー {file_path} batch {i//batch_size + 1}: {e}")
                # バッチ失敗時は個別にポイントを追加
                for point in batch_points:
                    try:
                        client.upsert(
                            collection_name=collection_name,
                            points=[point]
                        )
                        stored += 1
                    except Exception as point_error:
                        logger.error(f"個別ポイント登録エラー {point.id}: {point_error}")
        
        # ファイルのハッシュを更新
        is_changed, file_hash = hash_manager.is_file_changed(file_path)
        if is_changed and file_hash:
            hash_manager.store_file_hash(file_path, file_hash)
    
    logger.info(f"保存ドキュメント数: {stored}")
    
    # クローンしたレポジトリをローカルから削除
    shutil.rmtree("/tmp/sample")
    logger.info("deleted local files")

    logger.info(f"end lambda_handler")